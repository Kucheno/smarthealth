var HealthInsuranceContract = artifacts.require(
  "./HealthInsuranceContract.sol"
);
module.exports = function (_deployer) {
  _deployer.deploy(HealthInsuranceContract);
};
